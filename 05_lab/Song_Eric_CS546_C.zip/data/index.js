const userApiData = require("./userApi");

module.exports = {
  users: userApiData,
};
